# إنشاء ملف APK — نظام الفا برو المحاسبي

> هذه الحزمة هي **مصدر فقط**. لم يتم بناء APK أثناء المراجعة.

ملف التثبيت التجريبي المتوقع بعد البناء:

`app-debug.apk`

المسار داخل ناتج Gradle:

`app/build/outputs/apk/debug/app-debug.apk`

## الطريقة 1: GitHub Actions

المشروع يحتوي على workflow جاهز في:

`.github/workflows/build-apk.yml`

بعد رفع المشروع إلى GitHub:
1. افتح تبويب **Actions**.
2. اختر **Build Android APK**.
3. شغّل **Run workflow**.
4. بعد نجاح البناء افتح نتيجة التشغيل.
5. من **Artifacts** نزّل `AlfaProAccounting-debug-apk`.
6. فك الضغط لتحصل على `app-debug.apk` ثم اختبره على الأجهزة المستهدفة.

الـworkflow يستخدم JDK 17 وAndroid SDK 36 وGradle 9.4.1 مباشرة، لذلك لا يعتمد على وجود `gradlew` داخل المستودع.

## الطريقة 2: Android Studio

1. افتح المشروع في Android Studio الحديث.
2. ثبّت Android SDK Platform 36 وBuild Tools 36.0.0.
3. نفّذ Gradle Sync وتأكد من عدم وجود أخطاء KSP/Room.
4. من القائمة اختر Build > Build APK(s).
5. بعد نجاح البناء ستجد الملف في:
   `app/build/outputs/apk/debug/app-debug.apk`

## البناء من الطرفية
الحزمة الأصلية لا تتضمن Gradle Wrapper كاملًا. يوجد `gradle-wrapper.properties` فقط. قبل استخدام `./gradlew assembleDebug` يجب توليد وإضافة Wrapper كامل من بيئة Gradle موثوقة.

> APK التجريبي Debug مناسب للاختبار الداخلي فقط. النسخة النهائية للإنتاج ينبغي توقيعها بمفتاح Release خاص ومحفوظ في مكان آمن، بعد استكمال اختبارات Android 12–16 والنسخ الاحتياطي والأمان المذكورة في `STATUS.md`.
