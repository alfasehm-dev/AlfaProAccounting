# نظام الفا برو المحاسبي

مشروع Android أصلي باللغة العربية (RTL) مبني بـ Kotlin وJetpack Compose وRoom/SQLite.

## الإصدار الحالي للمصدر
- `versionCode = 2`
- `versionName = 1.0.0-alpha02`
- `compileSdk = 36`
- `targetSdk = 36`
- `minSdk = 29`

المشروع يستهدف Android 12 وما فوق، مع بقاء الحد الأدنى Android 10 (API 29). الاسم الظاهر للمستخدم هو **نظام الفا برو المحاسبي**.

> ملاحظة توافق مهمة: تم الإبقاء على `applicationId = com.alhamlawi.accounting` واسم قاعدة البيانات `alhamlawi_accounting.db` دون تغيير، حتى لا يُعامل التطبيق كتطبيق جديد ولا ينقطع مسار بيانات المستخدمين في تحديثات مستقبلية.

## المتطلبات
- Android Studio حديث يدعم Android 16.
- Android SDK Platform 36 + Build Tools 36.x.
- JDK 17 أو أحدث مدعوم بواسطة Android Studio.
- اتصال إنترنت في أول Build لتنزيل تبعيات Gradle/Maven.

## فتح المشروع
1. افتح مجلد المشروع في Android Studio.
2. تأكد من تثبيت SDK 36 من SDK Manager.
3. دع Gradle يقوم بالمزامنة.
4. اختبر على Android 12 / 13 / 14 / 15 / 16، وليس على API 36 فقط.

## أول تشغيل
لا توجد كلمة مرور افتراضية. تظهر شاشة لإنشاء حساب المدير الأول محليًا. الحد الأدنى الحالي للرمز السري هو 8 خانات.

## Build APK
لم يتم بناء APK ضمن حزمة المصدر هذه.

يمكن البناء من Android Studio عبر:
`Build > Build APK(s)`

أو باستخدام GitHub Actions الموجود في:
`.github/workflows/build-apk.yml`

المسار المعتاد بعد البناء:
`app/build/outputs/apk/debug/app-debug.apk`

### Gradle Wrapper
الحزمة الأصلية تحتوي `gradle/wrapper/gradle-wrapper.properties` فقط ولا تحتوي `gradlew` أو `gradlew.bat` أو `gradle-wrapper.jar`. لم يتم توليدها هنا لأن هذه المراجعة لا تشغّل Gradle. لذلك لا تعتمد على `./gradlew` حتى يتم توليد Wrapper كامل في بيئة Gradle موثوقة.

## بيانات التطبيق
- قاعدة البيانات: Room/SQLite باسم `alhamlawi_accounting.db` داخل مساحة التطبيق الخاصة.
- المبالغ: `Long` بالريال اليمني لتجنب أخطاء floating point.
- التواريخ: ISO `YYYY-MM-DD` لتسهيل الفرز والتجميع.
- سداد الديون: جدول مستقل `debt_payments`، ولا يتم تغيير الرصيد الأصلي مباشرة.
- الأرصدة الدائنة والمدينة تعرض منفصلة في الملخص والتقارير بدل جمعهما في رقم واحد.
- تقرير المديونية يفلتر حسب `dueDate` للفترة المختارة.

## Room Schema
`exportSchema = true` مع إعداد مسار `app/schemas`. لم يتم إنشاء JSON للمخطط بعد لأن ذلك يحدث وقت البناء الفعلي.

## النسخ الاحتياطي
النسخ الاحتياطي المشفر والاستعادة الكاملة ما زالا ضمن قائمة العمل في `STATUS.md`. لا تعتمد على النسخ التلقائي للنظام؛ تم تعطيله للبيانات المالية في الـ Manifest.

## Android 12–16
المشروع يستخدم `compileSdk = 36` و`targetSdk = 36`، و`android:exported="true"` للـLauncher Activity، ويستعمل edge-to-edge عبر `enableEdgeToEdge()` وRTL على مستوى Compose/Manifest.
