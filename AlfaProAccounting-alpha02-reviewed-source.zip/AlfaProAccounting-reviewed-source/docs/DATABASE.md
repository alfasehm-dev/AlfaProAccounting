# مخطط قاعدة البيانات

الجداول الحالية:
- users
- expenses
- doctor_payments
- suspenses
- debts
- debt_payments
- audit_logs

قاعدة الرصيد لكل مديونية:
`remaining = originalAmount - SUM(debt_payments.amount)`

أي سداد يتم داخل Room transaction، ويُرفض إذا كان أكبر من الرصيد المتبقي.

الحقل `direction` يميز بين `دائن` و`مدين`. لا يتم دمج الاتجاهين في إجمالي واحد في واجهة الملخص أو التقرير، لتجنب إعطاء رقم محاسبي ملتبس دون تعريف صريح لقواعد صافي الرصيد.

نسخة قاعدة البيانات ما تزال `version = 1` لأن التعديلات الحالية لم تغيّر الجداول أو الأعمدة. `exportSchema = true` ومسار تصدير المخطط مضبوط إلى `app/schemas`؛ ملف JSON الفعلي يُولد عند البناء.
