package com.alhamlawi.accounting

import com.alhamlawi.accounting.util.Accounting
import org.junit.Assert.*
import org.junit.Test

class AccountingTest {
    @Test fun amountParsingRejectsInvalidValues() {
        assertEquals(125000L, Accounting.parseAmount("125,000"))
        assertNull(Accounting.parseAmount("0"))
        assertNull(Accounting.parseAmount("-1"))
        assertNull(Accounting.parseAmount("abc"))
    }

    @Test fun remainingNeverBecomesNegative() {
        assertEquals(70000L, Accounting.remaining(100000L, 30000L))
        assertEquals(0L, Accounting.remaining(100000L, 120000L))
    }

    @Test fun isoDateValidationWorks() {
        assertTrue(Accounting.isIsoDate("2026-09-21"))
        assertFalse(Accounting.isIsoDate("21/09/2026"))
    }
}
