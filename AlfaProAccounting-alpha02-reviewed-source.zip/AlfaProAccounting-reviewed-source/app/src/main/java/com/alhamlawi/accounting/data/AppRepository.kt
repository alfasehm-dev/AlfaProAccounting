package com.alhamlawi.accounting.data

import androidx.room.withTransaction
import com.alhamlawi.accounting.security.PasswordHasher
import kotlinx.coroutines.flow.Flow

class AppRepository(private val db: AppDatabase) {
    val expenses: Flow<List<ExpenseEntity>> = db.expenseDao().observeAll()
    val doctorPayments: Flow<List<DoctorPaymentEntity>> = db.doctorPaymentDao().observeAll()
    val suspenses: Flow<List<SuspenseEntity>> = db.suspenseDao().observeAll()
    val debts: Flow<List<DebtWithPaid>> = db.debtDao().observeWithPaid()
    val audits: Flow<List<AuditLogEntity>> = db.auditDao().observeRecent()

    suspend fun needsAdminSetup(): Boolean = db.userDao().count() == 0

    suspend fun createFirstManager(username: String, password: String): Long {
        require(db.userDao().count() == 0) { "تم إنشاء المدير مسبقاً" }
        require(username.trim().length >= 3) { "اسم المستخدم قصير" }
        require(password.length >= 8) { "الرمز السري يجب ألا يقل عن 8 خانات" }
        val salt = PasswordHasher.newSalt()
        val hash = PasswordHasher.hash(password.toCharArray(), salt)
        return db.userDao().insert(UserEntity(username = username.trim(), passwordHash = hash, passwordSalt = salt))
    }

    suspend fun login(username: String, password: String): UserEntity? {
        val user = db.userDao().byUsername(username.trim()) ?: return null
        return if (PasswordHasher.verify(password.toCharArray(), user.passwordSalt, user.passwordHash)) user else null
    }

    suspend fun addExpense(item: ExpenseEntity): Long = db.withTransaction {
        val id = db.expenseDao().insert(item)
        audit(item.createdBy, "ADD", "EXPENSE", id, item.toString())
        id
    }

    suspend fun addDoctorPayment(item: DoctorPaymentEntity): Long = db.withTransaction {
        val id = db.doctorPaymentDao().insert(item)
        audit(item.createdBy, "ADD", "DOCTOR_PAYMENT", id, item.toString())
        id
    }

    suspend fun addSuspense(item: SuspenseEntity): Long = db.withTransaction {
        val id = db.suspenseDao().insert(item)
        audit(item.createdBy, "ADD", "SUSPENSE", id, item.toString())
        id
    }

    suspend fun updateSuspenseStatus(userId: Long, id: Long, status: String, paidDate: String?) = db.withTransaction {
        db.suspenseDao().updateStatus(id, status, paidDate, System.currentTimeMillis())
        audit(userId, "STATUS_CHANGE", "SUSPENSE", id, "status=$status;paidDate=$paidDate")
    }

    suspend fun addDebt(item: DebtEntity): Long = db.withTransaction {
        val id = db.debtDao().insert(item)
        audit(item.createdBy, "ADD", "DEBT", id, item.toString())
        id
    }

    suspend fun payDebt(userId: Long, debtId: Long, amount: Long, paymentDate: String, description: String): Long = db.withTransaction {
        require(amount > 0) { "قيمة السداد يجب أن تكون أكبر من صفر" }
        val remaining = db.debtDao().remaining(debtId) ?: error("الدين غير موجود")
        require(amount <= remaining) { "قيمة السداد أكبر من الرصيد المتبقي" }
        val id = db.debtDao().insertPayment(
            DebtPaymentEntity(
                debtId = debtId,
                amount = amount,
                paymentDate = paymentDate,
                description = description,
                createdBy = userId
            )
        )
        audit(userId, "PAYMENT", "DEBT", debtId, "paymentId=$id;amount=$amount")
        id
    }

    private suspend fun audit(userId: Long, action: String, type: String, id: Long, newValues: String) {
        db.auditDao().insert(
            AuditLogEntity(
                userId = userId,
                action = action,
                entityType = type,
                entityId = id,
                newValues = newValues
            )
        )
    }
}
