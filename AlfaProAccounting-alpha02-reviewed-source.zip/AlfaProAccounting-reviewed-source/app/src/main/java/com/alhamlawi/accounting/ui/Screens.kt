package com.alhamlawi.accounting.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alhamlawi.accounting.data.*
import com.alhamlawi.accounting.util.Accounting

@Composable
fun SetupAdminScreen(vm: AppViewModel) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    CenterCard("إعداد التطبيق لأول مرة") {
        Text("أنشئ حساب المدير. لا توجد كلمة مرور افتراضية داخل التطبيق.")
        OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم") }, singleLine = true)
        OutlinedTextField(
            password,
            { password = it },
            label = { Text("الرمز السري") },
            supportingText = { Text("8 خانات على الأقل") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation()
        )
        Button(
            enabled = username.trim().length >= 3 && password.length >= 8,
            onClick = { vm.createManager(username, password) {} },
            modifier = Modifier.fillMaxWidth()
        ) { Text("إنشاء حساب المدير") }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    CenterCard("تسجيل الدخول") {
        OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم") }, singleLine = true)
        OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور / PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        Button(onClick = { vm.login(username, password) }, modifier = Modifier.fillMaxWidth()) { Text("دخول") }
    }
}

@Composable
private fun CenterCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                content()
            }
        }
    }
}

@Composable
fun DashboardScreen(vm: AppViewModel, onReports: () -> Unit) {
    val expenses by vm.expenses.collectAsStateWithLifecycle()
    val doctors by vm.doctorPayments.collectAsStateWithLifecycle()
    val suspenses by vm.suspenses.collectAsStateWithLifecycle()
    val debts by vm.debts.collectAsStateWithLifecycle()
    val today = Accounting.today()
    val month = today.take(7)

    val monthExpenses = expenses.filter { it.transactionDate.startsWith(month) }.sumOf { it.amount }
    val monthDoctors = doctors.filter { it.transactionDate.startsWith(month) }.sumOf { it.amount }
    val pending = suspenses.filter { it.status == SuspenseStatuses.PENDING }.sumOf { it.amount }
    val creditRemaining = debts.filter { it.direction == DebtDirections.CREDIT }.sumOf { it.remainingAmount }
    val debitRemaining = debts.filter { it.direction == DebtDirections.DEBIT }.sumOf { it.remainingAmount }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("الملخص المالي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { SummaryCard("مصروفات الشهر", monthExpenses) }
        item { SummaryCard("نسب ومواصلات الأطباء - الشهر", monthDoctors) }
        item { SummaryCard("المعلقات غير المدفوعة", pending) }
        item { SummaryCard("الأرصدة الدائنة المتبقية", creditRemaining) }
        item { SummaryCard("الأرصدة المدينة المتبقية", debitRemaining) }
        item { Button(onClick = onReports, modifier = Modifier.fillMaxWidth()) { Text("عرض التقارير") } }
    }
}

@Composable
private fun SummaryCard(title: String, amount: Long) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(title); Text(Accounting.formatAmount(amount), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
}

@Composable
fun ExpensesScreen(vm: AppViewModel) {
    val data by vm.expenses.collectAsStateWithLifecycle()
    var showForm by remember { mutableStateOf(false) }
    ModuleScreen("إجمالي المصروفات", onAdd = { showForm = true }) {
        items(data) { item -> TransactionRow(item.category, item.description, item.transactionDate, item.amount) }
    }
    if (showForm) ExpenseForm(vm) { showForm = false }
}

@Composable
private fun ExpenseForm(vm: AppViewModel, close: () -> Unit) {
    var category by remember { mutableStateOf(ExpenseCategories.all.first()) }
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Accounting.today()) }
    var notes by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf(emptyList<String>()) }
    val valid = description.isNotBlank() && Accounting.parseAmount(amount) != null && Accounting.isIsoDate(date)

    EntryDialog("إضافة مصروف", close) {
        DropdownField("الفئة", ExpenseCategories.all, category) { category = it }
        OutlinedTextField(description, { description = it }, label = { Text("البيان") }, modifier = Modifier.fillMaxWidth())
        MoneyField(amount) { amount = it }
        DateField(date) { date = it }
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
        AttachmentPicker(attachments) { attachments = it }
        Button(
            enabled = valid,
            onClick = { vm.addExpense(category, description.trim(), Accounting.parseAmount(amount)!!, date, notes, attachments.joinToString("\n"), close) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ") }
    }
}

@Composable
fun DoctorPaymentsScreen(vm: AppViewModel) {
    val data by vm.doctorPayments.collectAsStateWithLifecycle()
    var showForm by remember { mutableStateOf(false) }
    ModuleScreen("إجمالي نسب الأطباء", onAdd = { showForm = true }) {
        items(data) { item -> TransactionRow("${item.type} - ${item.doctorName}", item.description, item.transactionDate, item.amount) }
    }
    if (showForm) DoctorPaymentForm(vm) { showForm = false }
}

@Composable
private fun DoctorPaymentForm(vm: AppViewModel, close: () -> Unit) {
    var doctor by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(DoctorPaymentTypes.all.first()) }
    var amount by remember { mutableStateOf("") }
    var percentage by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Accounting.today()) }
    var attachments by remember { mutableStateOf(emptyList<String>()) }
    val percentageText = percentage.trim()
    val pct = percentageText.takeIf { it.isNotEmpty() }?.toDoubleOrNull()
    val validPct = percentageText.isEmpty() || (pct != null && pct in 0.0..100.0)
    val valid = doctor.isNotBlank() && Accounting.parseAmount(amount) != null && validPct && Accounting.isIsoDate(date)
    EntryDialog("إضافة حركة طبيب", close) {
        OutlinedTextField(doctor, { doctor = it }, label = { Text("اسم الطبيب") }, modifier = Modifier.fillMaxWidth())
        DropdownField("النوع", DoctorPaymentTypes.all, type) { type = it }
        MoneyField(amount) { amount = it }
        OutlinedTextField(
            percentage,
            { value -> percentage = value.filter { it.isDigit() || it == '.' } },
            label = { Text("النسبة % - اختيارية") },
            supportingText = { if (!validPct) Text("أدخل رقماً بين 0 و100") },
            isError = !validPct,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(description, { description = it }, label = { Text("البيان") }, modifier = Modifier.fillMaxWidth())
        DateField(date) { date = it }
        AttachmentPicker(attachments) { attachments = it }
        Button(
            enabled = valid,
            onClick = { vm.addDoctorPayment(doctor.trim(), type, Accounting.parseAmount(amount)!!, pct, description, date, attachments.joinToString("\n"), close) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ") }
    }
}

@Composable
fun SuspensesScreen(vm: AppViewModel) {
    val data by vm.suspenses.collectAsStateWithLifecycle()
    var showForm by remember { mutableStateOf(false) }
    ModuleScreen("المعلقات", onAdd = { showForm = true }) {
        items(data) { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    TransactionRowContent(item.status, item.description, item.transactionDate, item.amount)
                    if (item.status == SuspenseStatuses.PENDING) TextButton(onClick = { vm.markSuspense(item.id, SuspenseStatuses.PAID, Accounting.today()) }) { Text("تحديد كمدفوع") }
                }
            }
        }
    }
    if (showForm) SuspenseForm(vm) { showForm = false }
}

@Composable
private fun SuspenseForm(vm: AppViewModel, close: () -> Unit) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(SuspenseStatuses.PENDING) }
    var date by remember { mutableStateOf(Accounting.today()) }
    var notes by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf(emptyList<String>()) }
    val valid = description.isNotBlank() && Accounting.parseAmount(amount) != null && Accounting.isIsoDate(date)
    EntryDialog("إضافة معلق", close) {
        OutlinedTextField(description, { description = it }, label = { Text("البيان") }, modifier = Modifier.fillMaxWidth())
        MoneyField(amount) { amount = it }
        DropdownField("الحالة", SuspenseStatuses.all, status) { status = it }
        DateField(date) { date = it }
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
        AttachmentPicker(attachments) { attachments = it }
        Button(
            enabled = valid,
            onClick = { vm.addSuspense(description.trim(), Accounting.parseAmount(amount)!!, status, date, attachments.joinToString("\n"), notes, close) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ") }
    }
}

@Composable
fun DebtsScreen(vm: AppViewModel) {
    val data by vm.debts.collectAsStateWithLifecycle()
    var showForm by remember { mutableStateOf(false) }
    var payDebt by remember { mutableStateOf<DebtWithPaid?>(null) }
    ModuleScreen("المديونية", onAdd = { showForm = true }) {
        items(data) { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${item.partyName} - ${item.direction}", fontWeight = FontWeight.Bold)
                    Text("${item.category} • استحقاق ${item.dueDate}")
                    Text("الأصلي: ${Accounting.formatAmount(item.originalAmount)}")
                    Text("المدفوع: ${Accounting.formatAmount(item.paidAmount)}")
                    Text("المتبقي: ${Accounting.formatAmount(item.remainingAmount)} • ${item.status}", fontWeight = FontWeight.Bold)
                    if (item.remainingAmount > 0) TextButton(onClick = { payDebt = item }) { Text("تسجيل سداد جزئي") }
                }
            }
        }
    }
    if (showForm) DebtForm(vm) { showForm = false }
    payDebt?.let { DebtPaymentForm(vm, it) { payDebt = null } }
}

@Composable
private fun DebtForm(vm: AppViewModel, close: () -> Unit) {
    var party by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(DoctorPaymentTypes.all.first()) }
    var direction by remember { mutableStateOf(DebtDirections.CREDIT) }
    var amount by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf(Accounting.today()) }
    var description by remember { mutableStateOf("") }
    var attachments by remember { mutableStateOf(emptyList<String>()) }
    val valid = party.isNotBlank() && Accounting.parseAmount(amount) != null && Accounting.isIsoDate(dueDate)
    EntryDialog("إضافة مديونية", close) {
        OutlinedTextField(party, { party = it }, label = { Text("الطرف / اسم الطبيب") }, modifier = Modifier.fillMaxWidth())
        DropdownField("النوع", DoctorPaymentTypes.all, category) { category = it }
        DropdownField("الرصيد", DebtDirections.all, direction) { direction = it }
        MoneyField(amount) { amount = it }
        DateField(dueDate, "تاريخ الاستحقاق") { dueDate = it }
        OutlinedTextField(description, { description = it }, label = { Text("البيان") }, modifier = Modifier.fillMaxWidth())
        AttachmentPicker(attachments) { attachments = it }
        Button(
            enabled = valid,
            onClick = { vm.addDebt(party.trim(), category, direction, Accounting.parseAmount(amount)!!, dueDate, description, attachments.joinToString("\n"), close) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("حفظ") }
    }
}

@Composable
private fun DebtPaymentForm(vm: AppViewModel, debt: DebtWithPaid, close: () -> Unit) {
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(Accounting.today()) }
    var description by remember { mutableStateOf("") }
    val parsed = Accounting.parseAmount(amount)
    val valid = parsed != null && parsed <= debt.remainingAmount && Accounting.isIsoDate(date)
    EntryDialog("سداد ${debt.partyName}", close) {
        Text("الرصيد المتبقي: ${Accounting.formatAmount(debt.remainingAmount)}")
        MoneyField(amount) { amount = it }
        DateField(date) { date = it }
        OutlinedTextField(description, { description = it }, label = { Text("بيان السداد") }, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = valid,
            onClick = { vm.payDebt(debt.id, parsed!!, date, description, close) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تسجيل السداد") }
    }
}

@Composable
fun ReportsScreen(vm: AppViewModel) {
    val expenses by vm.expenses.collectAsStateWithLifecycle()
    val doctors by vm.doctorPayments.collectAsStateWithLifecycle()
    val suspenses by vm.suspenses.collectAsStateWithLifecycle()
    val debts by vm.debts.collectAsStateWithLifecycle()
    var period by remember { mutableStateOf("شهري") }
    val today = Accounting.today()
    val predicate: (String) -> Boolean = when (period) {
        "يومي" -> { d -> d == today }
        "سنوي" -> { d -> d.startsWith(today.take(4)) }
        else -> { d -> d.startsWith(today.take(7)) }
    }
    val ex = expenses.filter { predicate(it.transactionDate) }.sumOf { it.amount }
    val doc = doctors.filter { predicate(it.transactionDate) }.sumOf { it.amount }
    val susp = suspenses.filter { predicate(it.transactionDate) }.sumOf { it.amount }
    val periodDebts = debts.filter { predicate(it.dueDate) }
    val creditDebt = periodDebts.filter { it.direction == DebtDirections.CREDIT }.sumOf { it.remainingAmount }
    val debitDebt = periodDebts.filter { it.direction == DebtDirections.DEBIT }.sumOf { it.remainingAmount }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("التقارير والملخصات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { DropdownField("الفترة", listOf("يومي", "شهري", "سنوي"), period) { period = it } }
        item { SummaryCard("المصروفات", ex) }
        item { SummaryCard("نسب ومواصلات الأطباء", doc) }
        item { SummaryCard("المعلقات المسجلة", susp) }
        item { SummaryCard("أرصدة دائنة مستحقة ضمن الفترة", creditDebt) }
        item { SummaryCard("أرصدة مدينة مستحقة ضمن الفترة", debitDebt) }
        item { Text("التصدير CSV/PDF/XLSX والفلترة المتقدمة موثقان للمرحلة التالية في STATUS.md.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun ModuleScreen(title: String, onAdd: () -> Unit, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Button(onClick = onAdd) { Text("إضافة") } } }
            content()
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun TransactionRow(title: String, description: String, date: String, amount: Long) {
    Card(Modifier.fillMaxWidth()) { TransactionRowContent(title, description, date, amount) }
}

@Composable
private fun TransactionRowContent(title: String, description: String, date: String, amount: Long) {
    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(title, fontWeight = FontWeight.Bold); Text(Accounting.formatAmount(amount), fontWeight = FontWeight.Bold) }
        if (description.isNotBlank()) Text(description)
        Text(date, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun EntryDialog(title: String, close: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        confirmButton = {},
        dismissButton = {},
        title = { Text(title) },
        text = { Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content(); TextButton(onClick = close, modifier = Modifier.align(Alignment.End)) { Text("إلغاء") } } }
    )
}

@Composable
private fun MoneyField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, { onChange(it.filter { c -> c.isDigit() || c == ',' }) }, label = { Text("المبلغ") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}

@Composable
private fun DateField(value: String, label: String = "التاريخ", onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text("$label (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = value.isNotBlank() && !Accounting.isIsoDate(value))
}

@Composable
private fun DropdownField(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selected) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) }
            }
        }
    }
}

@Composable
private fun AttachmentPicker(current: List<String>, onChange: (List<String>) -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri -> runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        onChange(uris.map { it.toString() })
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("المرفقات: ${current.size}")
        OutlinedButton(onClick = { launcher.launch(arrayOf("image/*", "application/pdf")) }) { Text("إرفاق") }
    }
}
