package com.alhamlawi.accounting.util

import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Accounting {
    fun parseAmount(input: String): Long? = input.replace(",", "").trim().toLongOrNull()?.takeIf { it > 0 }
    fun formatAmount(amount: Long): String = NumberFormat.getNumberInstance(Locale.US).format(amount) + " ر.ي"
    fun today(): String = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
    fun isIsoDate(value: String): Boolean = try {
        LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE); true
    } catch (_: Exception) { false }
    fun remaining(original: Long, paid: Long): Long = (original - paid).coerceAtLeast(0)
}
