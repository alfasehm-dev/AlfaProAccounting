package com.alhamlawi.accounting.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        ExpenseEntity::class,
        DoctorPaymentEntity::class,
        SuspenseEntity::class,
        DebtEntity::class,
        DebtPaymentEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun doctorPaymentDao(): DoctorPaymentDao
    abstract fun suspenseDao(): SuspenseDao
    abstract fun debtDao(): DebtDao
    abstract fun auditDao(): AuditDao

    companion object {
        fun create(context: Context): AppDatabase = Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "alhamlawi_accounting.db"
        ).build()
    }
}
