package com.alhamlawi.accounting.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object Roles {
    const val MANAGER = "MANAGER"
    const val ACCOUNTANT = "ACCOUNTANT"
    const val READER = "READER"
}

object ExpenseCategories {
    val all = listOf(
        "محاليل مختبر",
        "مشتريات طبية",
        "مشتريات أخرى",
        "دعم رواتب مكتب الصحة",
        "تسديد التزامات سابقة",
        "أخرى"
    )
}

object DoctorPaymentTypes {
    val all = listOf("نسب أطباء", "مواصلات أطباء")
}

object SuspenseStatuses {
    const val PENDING = "معلق"
    const val PAID = "مدفوع"
    val all = listOf(PENDING, PAID)
}

object DebtDirections {
    const val CREDIT = "دائن"
    const val DEBIT = "مدين"
    val all = listOf(CREDIT, DEBIT)
}

@Entity(tableName = "users", indices = [Index(value = ["username"], unique = true)])
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val passwordSalt: String,
    val role: String = Roles.MANAGER,
    val active: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val description: String,
    val amount: Long,
    val transactionDate: String,
    val notes: String = "",
    val attachments: String = "",
    val createdBy: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(tableName = "doctor_payments")
data class DoctorPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val doctorName: String,
    val type: String,
    val amount: Long,
    val percentage: Double? = null,
    val description: String = "",
    val transactionDate: String,
    val attachments: String = "",
    val createdBy: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(tableName = "suspenses")
data class SuspenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String,
    val amount: Long,
    val status: String = SuspenseStatuses.PENDING,
    val transactionDate: String,
    val paidDate: String? = null,
    val attachments: String = "",
    val notes: String = "",
    val createdBy: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val partyName: String,
    val category: String,
    val direction: String,
    val originalAmount: Long,
    val dueDate: String,
    val description: String = "",
    val attachments: String = "",
    val createdBy: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(
    tableName = "debt_payments",
    foreignKeys = [ForeignKey(
        entity = DebtEntity::class,
        parentColumns = ["id"],
        childColumns = ["debtId"],
        onDelete = ForeignKey.RESTRICT
    )],
    indices = [Index("debtId")]
)
data class DebtPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val debtId: Long,
    val amount: Long,
    val paymentDate: String,
    val description: String = "",
    val createdBy: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val action: String,
    val entityType: String,
    val entityId: Long,
    val oldValues: String = "",
    val newValues: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class DebtWithPaid(
    val id: Long,
    val partyName: String,
    val category: String,
    val direction: String,
    val originalAmount: Long,
    val dueDate: String,
    val description: String,
    val attachments: String,
    val createdBy: Long,
    val createdAt: Long,
    val deletedAt: Long?,
    val paidAmount: Long
) {
    val remainingAmount: Long get() = (originalAmount - paidAmount).coerceAtLeast(0)
    val status: String get() = when {
        remainingAmount == 0L -> "مسدد بالكامل"
        paidAmount > 0L -> "مسدد جزئياً"
        else -> "غير مسدد"
    }
}
