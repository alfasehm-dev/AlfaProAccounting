package com.alhamlawi.accounting

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.LayoutDirection.Rtl
import com.alhamlawi.accounting.ui.AppRoot
import com.alhamlawi.accounting.ui.theme.AlHamlawiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides Rtl) {
                AlHamlawiTheme {
                    AppRoot()
                }
            }
        }
    }
}
