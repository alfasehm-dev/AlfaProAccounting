package com.alhamlawi.accounting.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alhamlawi.accounting.AlHamlawiApp

private enum class MainSection(val label: String) {
    DASHBOARD("الرئيسية"), EXPENSES("المصروفات"), DOCTORS("الأطباء"), SUSPENSES("المعلقات"), DEBTS("المديونية"), REPORTS("التقارير")
}

@Composable
fun AppRoot() {
    val app = LocalContext.current.applicationContext as AlHamlawiApp
    val vm: AppViewModel = viewModel(factory = AppViewModel.Factory(app.repository))
    val setup by vm.setupRequired.collectAsStateWithLifecycle()
    val user by vm.currentUser.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize()) {
        when {
            setup == null -> Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
            setup == true -> SetupAdminScreen(vm)
            user == null -> LoginScreen(vm)
            else -> MainShell(vm)
        }
        message?.let { SnackbarMessage(it) { vm.clearMessage() } }
    }
}

@Composable
private fun SnackbarMessage(message: String, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = androidx.compose.ui.Alignment.BottomCenter) {
        Snackbar(action = { TextButton(onClick = onDismiss) { Text("إغلاق") } }) { Text(message) }
    }
}

@Composable
private fun MainShell(vm: AppViewModel) {
    var section by remember { mutableStateOf(MainSection.DASHBOARD) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("نظام الفا برو المحاسبي") },
                actions = { IconButton(onClick = { vm.logout() }) { Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج") } }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf(MainSection.DASHBOARD, MainSection.EXPENSES, MainSection.DOCTORS, MainSection.SUSPENSES, MainSection.DEBTS).forEach { item ->
                    NavigationBarItem(
                        selected = section == item,
                        onClick = { section = item },
                        icon = { Icon(iconFor(item), null) },
                        label = { Text(item.label, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (section) {
                MainSection.DASHBOARD -> DashboardScreen(vm, onReports = { section = MainSection.REPORTS })
                MainSection.EXPENSES -> ExpensesScreen(vm)
                MainSection.DOCTORS -> DoctorPaymentsScreen(vm)
                MainSection.SUSPENSES -> SuspensesScreen(vm)
                MainSection.DEBTS -> DebtsScreen(vm)
                MainSection.REPORTS -> ReportsScreen(vm)
            }
        }
    }
}

private fun iconFor(section: MainSection) = when (section) {
    MainSection.DASHBOARD -> Icons.Default.Home
    MainSection.EXPENSES -> Icons.Default.ReceiptLong
    MainSection.DOCTORS -> Icons.Default.MedicalServices
    MainSection.SUSPENSES -> Icons.Default.HourglassBottom
    MainSection.DEBTS -> Icons.Default.AccountBalanceWallet
    MainSection.REPORTS -> Icons.Default.Assessment
}
