package com.alhamlawi.accounting.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT COUNT(*) FROM users") suspend fun count(): Int
    @Query("SELECT * FROM users WHERE username = :username AND active = 1 LIMIT 1") suspend fun byUsername(username: String): UserEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(user: UserEntity): Long
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses WHERE deletedAt IS NULL ORDER BY transactionDate DESC, id DESC")
    fun observeAll(): Flow<List<ExpenseEntity>>
    @Insert suspend fun insert(item: ExpenseEntity): Long
    @Query("UPDATE expenses SET deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id") suspend fun softDelete(id: Long, deletedAt: Long)
}

@Dao
interface DoctorPaymentDao {
    @Query("SELECT * FROM doctor_payments WHERE deletedAt IS NULL ORDER BY transactionDate DESC, id DESC")
    fun observeAll(): Flow<List<DoctorPaymentEntity>>
    @Insert suspend fun insert(item: DoctorPaymentEntity): Long
    @Query("UPDATE doctor_payments SET deletedAt = :deletedAt WHERE id = :id") suspend fun softDelete(id: Long, deletedAt: Long)
}

@Dao
interface SuspenseDao {
    @Query("SELECT * FROM suspenses WHERE deletedAt IS NULL ORDER BY transactionDate DESC, id DESC")
    fun observeAll(): Flow<List<SuspenseEntity>>
    @Insert suspend fun insert(item: SuspenseEntity): Long
    @Query("UPDATE suspenses SET status = :status, paidDate = :paidDate, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, paidDate: String?, updatedAt: Long)
}

@Dao
interface DebtDao {
    @Query("""
        SELECT d.*, COALESCE(SUM(p.amount), 0) AS paidAmount
        FROM debts d
        LEFT JOIN debt_payments p ON p.debtId = d.id
        WHERE d.deletedAt IS NULL
        GROUP BY d.id
        ORDER BY d.dueDate ASC, d.id DESC
    """)
    fun observeWithPaid(): Flow<List<DebtWithPaid>>

    @Insert suspend fun insert(item: DebtEntity): Long
    @Insert suspend fun insertPayment(item: DebtPaymentEntity): Long

    @Query("""
        SELECT d.originalAmount - COALESCE((SELECT SUM(amount) FROM debt_payments WHERE debtId = d.id), 0)
        FROM debts d WHERE d.id = :debtId LIMIT 1
    """)
    suspend fun remaining(debtId: Long): Long?
}

@Dao
interface AuditDao {
    @Insert suspend fun insert(item: AuditLogEntity): Long
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int = 200): Flow<List<AuditLogEntity>>
}
