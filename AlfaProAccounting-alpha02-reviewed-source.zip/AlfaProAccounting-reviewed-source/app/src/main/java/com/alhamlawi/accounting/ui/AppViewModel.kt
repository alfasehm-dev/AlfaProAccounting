package com.alhamlawi.accounting.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alhamlawi.accounting.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(private val repo: AppRepository) : ViewModel() {
    private val _setupRequired = MutableStateFlow<Boolean?>(null)
    val setupRequired = _setupRequired.asStateFlow()

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser = _currentUser.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()

    val expenses = repo.expenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val doctorPayments = repo.doctorPayments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val suspenses = repo.suspenses.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val debts = repo.debts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val audits = repo.audits.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { refreshSetupState() }

    fun refreshSetupState() = viewModelScope.launch { _setupRequired.value = repo.needsAdminSetup() }

    fun createManager(username: String, password: String, onDone: () -> Unit) = viewModelScope.launch {
        runCatching { repo.createFirstManager(username, password) }
            .onSuccess { _setupRequired.value = false; _message.value = "تم إنشاء حساب المدير"; onDone() }
            .onFailure { _message.value = it.message ?: "تعذر إنشاء الحساب" }
    }

    fun login(username: String, password: String) = viewModelScope.launch {
        val user = repo.login(username, password)
        if (user == null) _message.value = "اسم المستخدم أو كلمة المرور غير صحيحة" else _currentUser.value = user
    }

    fun logout() { _currentUser.value = null }
    fun clearMessage() { _message.value = null }

    fun addExpense(category: String, description: String, amount: Long, date: String, notes: String, attachments: String, afterSuccess: () -> Unit = {}) = launchUserAction(afterSuccess) {
        repo.addExpense(ExpenseEntity(category = category, description = description, amount = amount, transactionDate = date, notes = notes, attachments = attachments, createdBy = it.id))
        "تم حفظ المصروف"
    }

    fun addDoctorPayment(doctor: String, type: String, amount: Long, percentage: Double?, description: String, date: String, attachments: String, afterSuccess: () -> Unit = {}) = launchUserAction(afterSuccess) {
        require(percentage == null || percentage in 0.0..100.0) { "النسبة يجب أن تكون بين 0 و100" }
        repo.addDoctorPayment(DoctorPaymentEntity(doctorName = doctor, type = type, amount = amount, percentage = percentage, description = description, transactionDate = date, attachments = attachments, createdBy = it.id))
        "تم حفظ حركة الطبيب"
    }

    fun addSuspense(description: String, amount: Long, status: String, date: String, attachments: String, notes: String, afterSuccess: () -> Unit = {}) = launchUserAction(afterSuccess) {
        repo.addSuspense(
            SuspenseEntity(
                description = description,
                amount = amount,
                status = status,
                transactionDate = date,
                paidDate = if (status == SuspenseStatuses.PAID) date else null,
                attachments = attachments,
                notes = notes,
                createdBy = it.id
            )
        )
        "تم حفظ المعلق"
    }

    fun markSuspense(id: Long, status: String, paidDate: String?) = launchUserAction {
        repo.updateSuspenseStatus(it.id, id, status, paidDate)
        "تم تحديث الحالة"
    }

    fun addDebt(party: String, category: String, direction: String, amount: Long, dueDate: String, description: String, attachments: String, afterSuccess: () -> Unit = {}) = launchUserAction(afterSuccess) {
        repo.addDebt(DebtEntity(partyName = party, category = category, direction = direction, originalAmount = amount, dueDate = dueDate, description = description, attachments = attachments, createdBy = it.id))
        "تم حفظ المديونية"
    }

    fun payDebt(debtId: Long, amount: Long, date: String, description: String, afterSuccess: () -> Unit = {}) = launchUserAction(afterSuccess) {
        repo.payDebt(it.id, debtId, amount, date, description)
        "تم تسجيل السداد"
    }

    private fun launchUserAction(afterSuccess: () -> Unit = {}, block: suspend (UserEntity) -> String) = viewModelScope.launch {
        val user = _currentUser.value ?: return@launch
        if (user.role == Roles.READER) { _message.value = "حساب القارئ لا يملك صلاحية التعديل"; return@launch }
        runCatching { block(user) }
            .onSuccess { result ->
                _message.value = result
                afterSuccess()
            }
            .onFailure { _message.value = it.message ?: "حدث خطأ" }
    }

    class Factory(private val repo: AppRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = AppViewModel(repo) as T
    }
}
