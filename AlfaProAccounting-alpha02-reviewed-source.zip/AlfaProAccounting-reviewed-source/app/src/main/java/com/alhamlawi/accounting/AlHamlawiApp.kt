package com.alhamlawi.accounting

import android.app.Application
import com.alhamlawi.accounting.data.AppDatabase
import com.alhamlawi.accounting.data.AppRepository

class AlHamlawiApp : Application() {
    val database by lazy { AppDatabase.create(this) }
    val repository by lazy { AppRepository(database) }
}
